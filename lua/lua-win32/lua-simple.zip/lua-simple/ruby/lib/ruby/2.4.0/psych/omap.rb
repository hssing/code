# frozen_string_literal: false
module Psych
  class Omap < ::Hash
  end
end
